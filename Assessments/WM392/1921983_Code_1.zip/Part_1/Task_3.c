#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

// defining constants
#define FILL_RATE 30
#define EMPTY_TARGET 50
#define BUCKET_SIZE 50
#define BUCKET_TOTAL 6

// define mutex
pthread_mutex_t mutexTank;
pthread_cond_t condTank;

// define variables
unsigned int tank_level = 0;
int bucket_levels[BUCKET_TOTAL] = { 0 };

// function to fill tank every 1 second by fill rate
void* fill_tank(void* arg) 
{
	// loop 10 times for 10 seconds
	for (int i = 0; i < 10; i++)
	{
		// lock mutex
		pthread_mutex_lock(&mutexTank);
		// fill tank
		tank_level += FILL_RATE;
		printf("Filling tank...Tank Level = %d\n", tank_level);
		// unlock mutex
		pthread_mutex_unlock(&mutexTank);
		// broadcast that condition variable is complete
		pthread_cond_broadcast(&condTank);
		// wait 1 second
		sleep(1);
	}
	return 0;
}

// function to empty tank into a bucket
void* empty_tank(void* arg) 
{
	// get bucket number from argument
	int bucket = arg;
	
	// lock mutex
	pthread_mutex_lock(&mutexTank);
	// while tank isn't full enough to empty
	while (tank_level < EMPTY_TARGET)
	{
		// not enough water in tank
		printf("Not enough water in tank...\n");
		// wait for condition variable - tank to fill
		pthread_cond_wait(&condTank, &mutexTank);
		// wait 1 second
		sleep(1);
	}
	// fill bucket
	bucket_levels[bucket] += BUCKET_SIZE;
	// empty tank
	tank_level -= BUCKET_SIZE;
	// unlock mutex
	pthread_mutex_unlock(&mutexTank);
	printf("Bucket %d has been filled! There is %dL left in the tank\n", bucket+1, tank_level);
	// wait 1 second
	sleep(1);
	return 0;
}

int main(int argc, char* argv[]) 
{
	// define threads
	pthread_t bucketThreads[BUCKET_TOTAL];
	pthread_t tankThread;

	// init mutex and conditon variable
	pthread_mutex_init(&mutexTank, NULL);
	pthread_cond_init(&condTank, NULL);

	// create tank thread
	pthread_create(&tankThread, NULL, fill_tank, NULL);

	// dynamically create bucket threads
	for (int i = 0; i < BUCKET_TOTAL; i++)
	{
		pthread_create(&bucketThreads[i], NULL, empty_tank, (int)i);
	}

	// join tank and bucket threads
	pthread_join(tankThread, NULL);
	for (int i = 0; i < BUCKET_TOTAL; i++)
	{
		pthread_join(bucketThreads[i], NULL);
	}

	// destroy mutex and conditon variables
	pthread_mutex_destroy(&mutexTank);
	pthread_cond_destroy(&condTank);

	// filling is complete
	printf("Filling Complete\n");
	// display that buckets are full
	for (int i = 0; i < BUCKET_TOTAL; i++)
	{
		printf("Bucket %d has %dL\n", i+1, bucket_levels[i]);
	}
	
	return 0;
}