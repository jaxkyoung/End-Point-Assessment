#include <stdio.h>
#include <pthread.h>

// size of array
#define MAX 100

// maximum number of threads
#define MAX_THREAD 5

// define list of integers
int list[MAX] = {0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 
				44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 
				88, 90, 92, 94, 96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 122, 124, 
				126, 128, 130, 132, 134, 136, 138, 140, 142, 144, 146, 148, 150, 152, 154, 156, 158, 160, 
				162, 164, 166, 168, 170, 172, 174, 176, 178, 180, 182, 184, 186, 188, 190, 192, 194, 196, 198};

// define list to store sums from each thread
int sum[MAX_THREAD] = { 0 };

// function to sum a portion of list
void* sum_part(void* arg)
{

	// Each thread computes sum of 1/MAX_THREAD of list
	// set thread part to section of list you want to sum i.e the thread number of (0 to MAX_THREAD)
	int thread_part = arg;

	// defining start and end of partial list
	int start = thread_part * (MAX / MAX_THREAD);
	int max = (thread_part + 1) * (MAX / MAX_THREAD);

	// print thread number and which portion it is summing. 
	printf("Thread Number: %d, it will sum from item %d to item %d\n", thread_part, start, max-1);
	for ( start; start < max; start++) {
		sum[thread_part] += list[start];
	}
}

// main code
int main()
{
	// define threads
	pthread_t sumThreads[MAX_THREAD];

	// Creating and joining MAX_THREAD threads
	for (int i = 0; i < MAX_THREAD; i++) {
		// create thread and link to sum function with no arguments
		pthread_create(&sumThreads[i], NULL, sum_part, (int)i);
		// join threads
		pthread_join(sumThreads[i], NULL);
	}

	// adding sum of all 4 parts
	int total_sum = 0;
	for (int i = 0; i < MAX_THREAD; i++) {
		printf("Sum %d is %d\n", i, sum[i]);
		total_sum += sum[i];
		
	}
	// output sum of list
	printf("Sum = %d\n", total_sum);

	return 0;
}

