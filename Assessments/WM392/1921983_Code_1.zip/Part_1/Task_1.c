#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

int counts = 0;
pthread_mutex_t mutex;

void* counter() {
    for (int i = 0; i < 1000000; i++) {
		pthread_mutex_lock(&mutex);
        counts++;
		pthread_mutex_unlock(&mutex);
    }
}

int main(int argc, char* argv[]) {
    pthread_t pth1, pth2;

	pthread_mutex_init(&mutex, NULL);
    pthread_create(&pth1, NULL, counter, NULL);
    pthread_create(&pth2, NULL, counter, NULL);

    pthread_join(pth1, NULL);
    pthread_join(pth2, NULL);
	pthread_mutex_destroy(&mutex);

    printf("The number of counts is %d.\n", counts);
    return 0;
}
