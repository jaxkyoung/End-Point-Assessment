#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "SFS_struct.h"

time_t getCurrentTime() {
	time_t now;
	time(&now);
	return ctime(&now);
}

superBlock_t SFS_init() {
	// define superBlock
	superBlock_t superBlock;
	// fill parameters
	superBlock.total_size = 0;
	superBlock.file_count = 0;
	superBlock.data_blocks = 0;
	// notify user
	printf("Initialising...\n");
	for (int i = 0; i < MAX_FILES; i++)
	{
		// populate inodes and fill superblock
		inode_t aFile;
		aFile.size = 0;
		superBlock.inode[i] = aFile;
	}
	// return the super block
	return superBlock;
}

void SFS_save(superBlock_t superBlock) {
	// define file pointer
	FILE *fptr;
	// create SFS data file
	fptr = fopen("SFS_DATA.txt", "w");
	// print inodes count
	fprintf(fptr, "inodes %d\n", superBlock.file_count);
	// print data block count 
	fprintf(fptr, "data-blocks %d\n", superBlock.data_blocks);
	// print total bytes 
	fprintf(fptr, "total-size %u\n", superBlock.total_size);
	for (int i = 0; i < superBlock.file_count; i++)
	{	
		// for each file in use
		inode_t file = superBlock.inode[i];
		// print file number, size, name, and time created
		fprintf(fptr, "%d %d %s %s" , i, file.size, file.fName, file.time_created);
		
	}
	// close file pointer
	fclose(fptr);
	// notify user
	printf("Saving...\n");
}

superBlock_t SFS_read() {
	// define variables
	char input[100];
	int input2;
	FILE *fptr;
	superBlock_t superBlock;
	// open sfs data to read
	fptr = fopen("SFS_DATA.txt", "r");
	if ((fptr == NULL))
	{
		// if doesnt exist then init
		printf("Error...\n");
		SFS_init();
	} else {
		// notify user of reading
		printf("Reading...\n");
		// read lines
		fscanf(fptr, "%s", input);
		if (strcmp(input, "inodes") == 0) {
			fscanf(fptr, "%d", &input2);
			// read data from file and populate superBlock
			superBlock.file_count = input2;
		}
		fscanf(fptr, "%s", input);
		if (strcmp(input, "data-blocks") == 0) {
			fscanf(fptr, "%d", &input2);
			// read data from file and populate superBlock
			superBlock.data_blocks = input2;
		}
		fscanf(fptr, "%s", input);
		if (strcmp(input, "total-size") == 0) {
			fscanf(fptr, "%d", &input2);
			// read data from file and populate superBlock
			superBlock.total_size = input2;
		}
		for (int i = 0; i < superBlock.file_count; i++){
			// define local variables to read file data
			int file_pos;
			int file_size;
			char filename[50];
			char date[100];
			// read file data
			fscanf(fptr, "%d", &file_pos);
			fscanf(fptr, "%d", &file_size);
			fscanf(fptr, "%s", filename);
			inode_t aFile;
			// populate file object
			strcpy(aFile.fName, filename);
			aFile.size = file_size;
			char line[500];
			while (fgets(line, sizeof(line), fptr)) {
			}
			// populate superBlock
			superBlock.inode[file_pos] = aFile;
		}
	}
	// return superBlock object
	return superBlock;
}

void strip_ext(char *fname)
{
    char *end = fname + strlen(fname);

    while (end > fname && *end != '.') {
        --end;
    }

    if (end > fname) {
        *end = '\0';
    }
}

// function to create file
superBlock_t SFS_create(superBlock_t superBlock, char* filename, int file_size) {
	// define file pointer
	FILE *fptr;
	// check if file exists
	if ((fptr = fopen(filename, "r")) != NULL) {
		// if file exists
		printf("File already exists...\n");
		return superBlock;
	} else {
		// if file does not exist loop through availabe nodes
		for (int i = 0; i < MAX_FILES; i++) {
			// define inode
			inode_t aFile;
			aFile = superBlock.inode[i];
			// if node is not in use
			if (aFile.size == 0) {
				// create file
				fptr = fopen(filename, "w");
				// give user feedback
				printf("Added %s\n", filename);
				// populate parameters for inode
				strcpy(aFile.fName, filename);
				aFile.size = file_size;
				aFile.time_created = getCurrentTime();
				// populate superblock
				superBlock.inode[i] = aFile;
				superBlock.file_count++;
				superBlock.total_size += file_size;
				// fill file
				strip_ext(filename);
				for (int j = 0; j < file_size; j++) {
					fprintf(fptr, "%s", filename);
				}
				fclose(fptr);
				// return superblock
				return superBlock;
			}
		}
		// if loop completes then no space in SFS
		printf("No space left in SFS, file not created\n");
		return superBlock;
	}
}

superBlock_t SFS_delete(superBlock_t superBlock, char* filename) {
	for (int i = 0; i < MAX_FILES; i++) {
		inode_t aFile;
		aFile = superBlock.inode[i];
		if (strcmp(aFile.fName, filename) == 0) {
			if (remove(filename) == 0) {
				strcpy(aFile.fName, "NULL");
				aFile.size = 0;
				superBlock.data_blocks -= aFile.block_count;
				superBlock.file_count--;
				superBlock.inode[i] = aFile;
				printf("File deleted successfully...\n");
				return superBlock;
			} else {
				printf("Error: File was not deleted...\n");
				return superBlock;
			}		
		}
	}
}

// function to display list of files
void SFS_display(superBlock_t superBlock) {
	// define file object
    inode_t file;
	// loop through files in superblock
    for (int i = 0; i < MAX_FILES; i++) {
        file = superBlock.inode[i];
		// if file is in use
		if (file.size != 0) {
			// show on list
        	printf("File Name: %s Size: %d Created: %s", file.fName, file.size, file.time_created);
		}
    }
}

int main()
{
	// define file pointer and superBlock object
	FILE *fptr;
	superBlock_t superBlock;
	// if data file exists then read 
	if ((fptr = fopen("SFS_DATA.txt", "r")) != NULL) {
		superBlock = SFS_read();
	} else {
	// else initialse the data file
		superBlock = SFS_init();
		// save data file
		SFS_save(superBlock);
	}

	// define variables to get user input
    char command[100], filename[100];
	int file_size;

	// main loop
    while (1) {
		// print prompt
        printf("Mini Shell>> ");
		// get command
        scanf("%s", command);
		// if command is save then save
        if (!strcasecmp(command, "save")) {
            SFS_save(superBlock);
		// if command is add then add file of size that is given by user
		} else if (!strcasecmp(command, "add")) {
			// get file name
            scanf("%s", filename);
			// get file size
			scanf("%d", &file_size);
			// create file and return new superblock
            superBlock = SFS_create(superBlock, filename, file_size);
			// save superblock
			SFS_save(superBlock);
		// if command is delete then delete
		} else if (!strcasecmp(command, "del")) {
			// get file name
            scanf("%s", filename);
			// delete file and return new super block
            superBlock = SFS_delete(superBlock, filename);
			// save block
			SFS_save(superBlock);
		// if command is read then read
		} else if (!strcasecmp(command, "read")) {
            SFS_read();
		// if command is ls then display
        } else if (!strcasecmp(command, "ls")) {
            SFS_display(superBlock);
		// exit 
        } else if (!strcasecmp(command, "exit")) {
            break;
        } else {
            printf("Wrong command...\n");
        }
    }
	return 0;
}