#include <time.h>

#define MAX_FILE_BLOCKS 39
#define MAX_BLOCKS 100
#define MAX_FILE_SIZE 10000
#define MAX_FILES 5
#define BLOCK_SIZE 256

/* Structure Definitions */
typedef struct dataBlock_t
{
	char data[BLOCK_SIZE];
	struct dataBlock_t* next_block;
} dataBlock_t;

typedef struct inode_t
{
	char fName[50];
	int size;
	time_t time_created;
	dataBlock_t blocks[MAX_FILE_BLOCKS];
	int block_count;
} inode_t;

typedef struct superBlock_t
{
	inode_t inode[MAX_FILES];
	int total_size;
	int file_count;
	int data_blocks;
} superBlock_t;