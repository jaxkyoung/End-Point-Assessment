# Assessment 3 U1921983

 Hello Jianhua, please find my source code in file *Assessment3.py*

The extra files needed to run my program are: 

 - Logins.txt
 - corporate.png

**They must be saved in the same folder as *Assessment3.py***
