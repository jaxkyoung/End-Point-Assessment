# importing libraries
import numpy as np
from tkinter import *  
# tkinter is the library i'm using for GUI
from tkinter import filedialog  
# filedialog allows me to use the file selection window
import tkinter.messagebox  
# messagebox allows me to use pop up message boxes
import hashlib  
# hashlib is a 3rd party library, it allows me to hash passwords
from sys import platform  
# allows me to check was OS is being used to save in the correct directory
from pathlib import Path
import os 

# initialising variables and instances
data = []
timestamps = []
window = tkinter.Tk()
file = ''


# function to get raw data from file and then manipulate it into lists
def getData():
    # tkinter function to open file browser and return the filepath
    try:
        filename =  filedialog.askopenfilename(initialdir = "/", title = "Select file",
        filetypes = (("asc files", "*.asc"), ("all files","*.*")))
        file = open(filename)
        tkinter.messagebox.showinfo("Success", "File loaded successfully")
        # loops through each line and ignores any error data, then appends to main data array
        for line in file:
            array = []
            array = line.split(" ")
            # lines that contain "Statistic" or "CAN" are ignored
            if "Statistic:" in array:
                continue
            elif "CAN" in array:
                continue
            elif "ErrorFrame" in array:
                continue
            else:
                data.append(array)
    except FileNotFoundError:
        # error message if file is not loaded
        tkinter.messagebox.showinfo("Error", "File loaded unsuccessfully, Please load another")
        getData()

# function to parse data and remove uneccessary parts
def parseData():
        for i in range(0, len(data)):
            for j in range(0, len(data[i])):
                # all uncessary data is from the postion that contains "Length" 
                # to the end of the line hence the ':'
                if data[i][j] == "Length":
                    del data[i][j:]
                    break

# function that returns the closest timestamps to user input numbers for start and end of desired section
# this function takes two parameters: the start and end time input by the user       
def dataManip(start, end):
    for i in range(0, len(data)):
        if len(data[i]) < 10:
            continue
        for j in range(0, len(data[i])):
            if len(data[i][j]) < 8:
                continue
            else:
                # when a timestamp is found it is appended to the timestamp array
                timestamps.append(float(data[i][j]))
    # finds the closest timestamp compared to what the user inputs
    try:
        starttime = min(timestamps, key=lambda x:abs(x-float(start)))
        endtime = min(timestamps, key=lambda x:abs(x-float(end)))
        return starttime, endtime
    except ValueError:
        # error message if file is not loaded
        tkinter.messagebox.showinfo("Error", "No file loaded, Restart Application")
        exit()

# function to get the path to users download folder for windows only
def get_download_path():
    """Returns the default downloads path for or windows"""
    if os.name == 'nt':
        import winreg
        sub_key = r'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'
        downloads_guid = '{374DE290-123F-4565-9164-39C4925E467B}'
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub_key) as key:
            location = winreg.QueryValueEx(key, downloads_guid)[0]
        return location
    else:
        return os.path.join(os.path.expanduser('~'), 'downloads')
    
def mainFunc(start, end, parse, OldCan1, OldCan2, OldCan3, OldCan4, OldCan5, OldCan6, OldCan7, OldCan8, OldCan9,
            NewCan1, NewCan2, NewCan3, NewCan4, NewCan5, NewCan6, NewCan7, NewCan8, NewCan9):
    # parse is the variable tracking the state of the parsing checkbox 
    # if its 1 then the box is ticked and parse function is called
    if parse == 1:
        parseData()
    elif parse == 0:
        pass
    
    # manipulation function is called passing the start and end times input by the user 
    # it returns them as a tuple
    newtimes = dataManip(start, end)

    # sindex and eindex are the index postions of the desired timestamps 
    # to then pass back to the original data array
    sindex = timestamps.index(newtimes[0])
    eindex = timestamps.index(newtimes[1])

    newdata = []  
    # this is the raw data between the new timestamps
    dataprint = []  
    # this is the data after being joined together
    filedetails = [] 
    # this is the first 6 lines to be put at the start of the file 
    string = " "

    # loops through the first six lines of the original 
    # data to collect file details, eg: data and time
    detailindex = 0
    for i in range(0, len(data)-1):
        if len(data[i]) < 9:
            joined = ''
            joined = string.join(data[i])
            filedetails.append(joined)
            detailindex = i + 1
    
    # loops through original data and add 
    # desired lines to new array from chosen timestamps
    for i in range(sindex + detailindex, eindex + detailindex):
        newdata.append(data[i])

    # this loop allows me to format all the timestamps to 6 sig figs as per the original file
    for i in range(0, len(newdata)):
        for j in range(0, len(newdata)):
            if newdata[i][j] != "":
                newdata[i][j] = float(newdata[i][j]) - newtimes[0]
                newdata[i][j] = format(newdata[i][j], '.6f')
                newdata[i][j] = str(newdata[i][j])
                break
    
    # these arrays save the chosen CAN channels to replace the old ones with
    oldcan = []
    newcan = []
    oldcan.append(OldCan1)
    oldcan.append(OldCan2)
    oldcan.append(OldCan3)
    oldcan.append(OldCan4)
    oldcan.append(OldCan5)
    oldcan.append(OldCan6)
    oldcan.append(OldCan7)
    oldcan.append(OldCan8)
    oldcan.append(OldCan9)
    newcan.append(NewCan1)
    newcan.append(NewCan2)
    newcan.append(NewCan3)
    newcan.append(NewCan4)
    newcan.append(NewCan5)
    newcan.append(NewCan6)
    newcan.append(NewCan7)
    newcan.append(NewCan8)
    newcan.append(NewCan9)

    # this loop replaces any /n with a blank space to allow me to correctly write to a file
    # it also changes the CAN channels as requested
    for i in range(0, len(newdata)):
        x = newdata[i][-1]
        txt = x.replace("\n", "")
        newdata[i][-1] = txt
        for j in range(0, 5):
            for x in range(0, (len(oldcan))):
                if newdata[i][j] == oldcan[x]:
                    newdata[i][j] = newcan[x]
    
    # loops through chosen data and joins each line 
    # into a concatenated string to then be able to write to a file
    for i in range(0, len(newdata)):
        joined = ''
        joined = string.join(newdata[i])
        dataprint.append(joined)

    # writes file details to file named "coversion" in 
    # the same format as it was given to the program
    if platform == "darwin":
        path_to_download_folder = str(os.path.join(Path.home(), "Downloads"))
        macpath = path_to_download_folder + "/conversion.asc"
        with open(macpath, 'w') as f:
            for item in filedetails:
                f.write("%s" % item)
        # writes each line of data to the file
            for item in dataprint:
                f.write("%s\n" % item)      
        # OS X
    elif platform == "Windows":
        # Windows...
        with open(get_download_path() + "/conversion.asc", 'w') as f:
            for item in filedetails:
                f.write("%s" % item)
        # writes each line of data to the file
            for item in dataprint:
                f.write("%s\n" % item)    
    tkinter.messagebox.showinfo("Process Complete", "Please rename the conversion file found in your downloads")

# function that is called to start the program, opens up the JLR login window I designed
def tkLogin():
    # to rename the title of the window
    window.title("CAN Analysis Login")
    # gives dimensions and postions of windows
    window.geometry("800x300+300+200")

    # loads JLR logo into the file
    # displaying the picture using a 'Label' by passing 
    # the 'logo' variable to 'image' parameter
    logo = tkinter.PhotoImage(file = "corporate.png")
    JLRLogo = tkinter.Label(window, image = logo)
    JLRLogo.pack()

    # sets a label and entry window to enter a username and stores it in variable 'user'
    user = StringVar()
    tkinter.Label(window, text = "Username").pack() 
    # 'Entry' is used to display the input-field
    username = tkinter.Entry(window, textvariable = user).pack()

    # sets a label and entry window to enter a password and stores it in variable 'passw'
    # it also hides password when entered and only shows asterisks
    passw = StringVar()
    tkinter.Label(window, text = "Password").pack() 
    password = tkinter.Entry(window, show = "*", textvariable = passw).pack()

    # 'Checkbutton' is used to create the check buttons
    # this is used to decide wether the user wants to stay logged in after the file has been converted
    keeplogin = IntVar()
    tkinter.Checkbutton(window, text = "Keep Me Logged In", variable = keeplogin).pack()

    # this button calls the loginTest function to check password and 
    # username against database of usernames and passwords
    loginbtn = tkinter.Button(window, text = "Log In", fg = "black",
    command = lambda: loginTest(user.get(), passw.get(), keeplogin.get()))
    loginbtn.pack()
    registerbtn = tkinter.Button(window, text = "Register", fg = "black",
    command = lambda: register(user.get(), passw.get(), keeplogin.get()))
    registerbtn.pack()

    # refreshes Tk window
    window.mainloop()

# function called when the "register" button is pressed and asks for master user and password
# then hashes password and adds to login file
list = []
def register(username, password, keeplogin):
    x = input("user: ")
    y = input("pass: ")
    hash_y = hashlib.sha1(y.encode())
    hex_y = hash_y.hexdigest()
    file = open("logins.txt")
    # finding if master pass and user are correct
    for line in file:
        array = []
        array = line.split(" ")
        if x in array[0] and hex_y in array[1]:
            file.close()
            login = []
            hash_password = hashlib.sha1(password.encode())
            hex_password = hash_password.hexdigest()
            if username == "" or password == "":
                tkinter.messagebox.showinfo("Error", "Username or Password not valid")
            else:
                # if user and password are allowed then they are added to login list
                login.append(username)
                login.append(hex_password)
                list.append(login)
                with open('logins.txt', 'a') as f:
                    for i in range(0, len(list)):
                        f.write("%s" % list[i][0])
                        f.write(" %s\n" % list[i][1])
                window.destroy()
                mainMenu()
                break
        else:
            tkinter.messagebox.showinfo("Error", "Admin details incorrect")
            break

# function to test that the username and password are correct, it is passed the variables
# username, password and keeplogin
logins = []
def loginTest(username, password, keeplogin):
    file = open("logins.txt")
    for line in file:
        array = []
        array = line.split(" ")
        logins.append(array)
    hash_password = hashlib.sha1(password.encode())
    hex_password = hash_password.hexdigest()
    # selection statement comparing user and password
    for i in range(0, len(logins)):
        if username == logins[i][0] and hex_password in logins[i][1]:
            # message box stating password was accepted
            tkinter.messagebox.showinfo("Access Granted", "Username and Password Accepted")
            # closing login window
            window.destroy()
            # opening main window by calling mainMenu function
            mainMenu()
            break
        # if the user or password is empty it outputs error message asking for both 
        elif username == "" or password == "":
            # tkinter.messagebox shows a pop up box with the title x and contents y (x, y)
            tkinter.messagebox.showinfo("Empty Fields", "You must input a username and password\nTry again")
            break
            #tkinter.messagebox.showinfo("Incorrect Login", "Incorrect Login\nPlease try again")
            #break
        else:
            if i == (len(logins)-1):
                tkinter.messagebox.showinfo("Access Denied", "Username and Password Not Accepted")
                break

def mainMenu():
    # to initalise menu as a tkinter window
    menu = tkinter.Tk()
    # to rename the title of the window
    menu.title("Main Menu")
    # setting size and position of window
    menu.geometry("800x500+300+200")
    # creating a root menu to insert all the sub menus
    dropdown = tkinter.Menu(menu)
    # adding the menu to the window
    menu.config(menu = dropdown)

    # creating sub menus in the root menu
    file_menu = tkinter.Menu(dropdown) 
    # it intializes a new sub menu in the root menu
    dropdown.add_cascade(label = "File", menu = file_menu) 
    # it creates the name of the sub menu
    file_menu.add_command(label = "New file.....", command = getData) 
    # it adds a option to the sub menu 'command' parameter is used to do some action
    file_menu.add_separator() 
    # it adds a line after the 'Open files' option
    file_menu.add_command(label = "Exit", command = menu.destroy) 
    # adds a menu option to exit out of the program

    logo = tkinter.PhotoImage(file = "corporate.png")
    # displaying the picture using a 'Label' by passing the 'logo' variable to 'image' parameter
    JLRLogo = tkinter.Label(menu, image = logo)
    JLRLogo.place(x =200 , y = 0)

    # using the same concept as the username and 
    # password section I created input boxes for the timestamps
    start = StringVar()
    tkinter.Label(menu, text = "Starting timestamp").place(x = 250 , y = 120) 
    # 'Entry' is used to display the input-field
    startstamp = tkinter.Entry(menu, textvariable = start).place(x = 215, y = 150)

    end = StringVar()
    tkinter.Label(menu, text = "Ending timestamp").place(x = 450, y = 120) 
    endstamp = tkinter.Entry(menu, textvariable = end).place(x = 425, y = 150)

    # values to fill the drop down boxes
    values = ["None", "1", "2", "3", "4", "5", "6", "7", "8", "9"]

    # initialising the variables to track what option is selected in the 
    # drop down boxes
    OldCan1 = StringVar()
    OldCan2 = StringVar()
    OldCan3 = StringVar()
    OldCan4 = StringVar()
    OldCan5 = StringVar()
    OldCan6 = StringVar()
    OldCan7 = StringVar()
    OldCan8 = StringVar()
    OldCan9 = StringVar()
    
    OldCan1.set('None')
    OldCan2.set('None')
    OldCan3.set('None')
    OldCan4.set('None')
    OldCan5.set('None')
    OldCan6.set('None')
    OldCan7.set('None')
    OldCan8.set('None')
    OldCan9.set('None')
    
    NewCan1 = StringVar()
    NewCan2 = StringVar()
    NewCan3 = StringVar()
    NewCan4 = StringVar()
    NewCan5 = StringVar()
    NewCan6 = StringVar()
    NewCan7 = StringVar()
    NewCan8 = StringVar()
    NewCan9 = StringVar()

    NewCan1.set('None')
    NewCan2.set('None')
    NewCan3.set('None')
    NewCan4.set('None')
    NewCan5.set('None')
    NewCan6.set('None')
    NewCan7.set('None')
    NewCan8.set('None')
    NewCan9.set('None')

    # labels and dropdown boxes being drawn in
    tkinter.Label(menu, text = "Current CAN Channel").place(x = 245, y = 185)

    dropdown1 = tkinter.OptionMenu(menu, OldCan1, *values)
    dropdown1.place(x = 275, y = 210)

    dropdown2 = tkinter.OptionMenu(menu, OldCan2, *values)
    dropdown2.place(x = 275, y = 235)

    dropdown3 = tkinter.OptionMenu(menu, OldCan3, *values)
    dropdown3.place(x = 275, y = 260)

    dropdown4 = tkinter.OptionMenu(menu, OldCan4, *values)
    dropdown4.place(x = 275, y = 285)

    dropdown5 = tkinter.OptionMenu(menu, OldCan5, *values)
    dropdown5.place(x = 275, y = 310)

    dropdown6 = tkinter.OptionMenu(menu, OldCan6, *values)
    dropdown6.place(x = 275, y = 335)

    dropdown7 = tkinter.OptionMenu(menu, OldCan7, *values)
    dropdown7.place(x = 275, y = 360)

    dropdown8 = tkinter.OptionMenu(menu, OldCan8, *values)
    dropdown8.place(x = 275, y = 385)

    dropdown9 = tkinter.OptionMenu(menu, OldCan9, *values)
    dropdown9.place(x = 275, y = 410)

    tkinter.Label(menu, text = "New CAN Channel").place(x = 450, y = 185)

    dropdown10 = tkinter.OptionMenu(menu, NewCan1, *values)
    dropdown10.place(x = 475, y = 210)

    dropdown11 = tkinter.OptionMenu(menu, NewCan2, *values)
    dropdown11.place(x = 475, y = 235)

    dropdown12 = tkinter.OptionMenu(menu, NewCan3, *values)
    dropdown12.place(x = 475, y = 260)

    dropdown13 = tkinter.OptionMenu(menu, NewCan4, *values)
    dropdown13.place(x = 475, y = 285)

    dropdown14 = tkinter.OptionMenu(menu, NewCan5, *values)
    dropdown14.place(x = 475, y = 310)

    dropdown15 = tkinter.OptionMenu(menu, NewCan6, *values)
    dropdown15.place(x = 475, y = 335)

    dropdown16 = tkinter.OptionMenu(menu, NewCan7, *values)
    dropdown16.place(x = 475, y = 360)

    dropdown17 = tkinter.OptionMenu(menu, NewCan8, *values)
    dropdown17.place(x = 475, y = 385)

    dropdown18 = tkinter.OptionMenu(menu, NewCan9, *values)
    dropdown18.place(x = 475, y = 410)

    # 'Checkbutton' is used to create the check buttons
    parse = IntVar()
    # the parsebutton checks if the user wants the data to 
    # parsed and if so it executes this in the mainFunc
    parsebutton = tkinter.Checkbutton(menu, text = "Parse Data", variable = parse).place(x = 350, y = 435)

    # startbtn is a button that calls the mainFunc and brings all functions together
    startbtn = tkinter.Button(menu, text = "Start conversion", fg = "black",
    command = lambda: mainFunc(start.get(), end.get(), parse.get(), OldCan1.get(), OldCan2.get(), OldCan3.get(), OldCan4.get(), 
    OldCan5.get(), OldCan6.get(), OldCan7.get(), OldCan8.get(), OldCan9.get(), NewCan1.get(), NewCan2.get(), NewCan3.get(), NewCan4.get(), NewCan5.get(),
    NewCan6.get(), NewCan7.get(), NewCan8.get(), NewCan9.get()))

    startbtn.place(x = 350, y = 460)

    menu.mainloop()

# calling the starting function to ask user to login
tkLogin()