from tkinter import filedialog # filedialog allows me to use the file selection window
filename =  filedialog.askopenfilename(initialdir = "/",title = "Select file",
filetypes = (("asc files","*.asc"),("all files","*.*")))
file = open(filename)
data = []
# loops through each line and ignores any error data, then appends to main data array
for line in file:
    array = []
    array = line.split(" ")
    # lines that contain "Statistic" or "CAN" are ignored
    if "Statistic:" in array:
        continue
    elif "CAN" in array:
        continue
    elif "ErrorFrame" in array:
        continue
    else:
        data.append(array)

print(data)