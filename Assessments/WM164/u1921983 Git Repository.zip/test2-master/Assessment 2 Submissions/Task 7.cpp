#include <iostream>
#include <string>
using namespace std;

//function to swap items in array to be used in bubbleSort
void swap(int *xp, int *yp)  
{  
    int temp = *xp;  
    *xp = *yp;  
    *yp = temp;  
}  

// A function to implement bubble sort  
void bubbleSort(int arr[], int n)  
{  
    int i, j;
    //two loops needed to iterate through both i and j
    for (i = 0; i < n-1; i++)      
      
    // Last i elements are already in place  
    for (j = 0; j < n-i-1; j++)  
        if (arr[j] > arr[j+1])  
        swap(&arr[j], &arr[j+1]);  
}  

//function to calculate median and mean
void calculate(int sorted[], int size, int arr[], string dealer[])
{
    //varibales needed for calculations
    int i = 0;
    int total = 0;
    int index = 0;
    int middle = (size + 1)/2;
    int median =  sorted[middle];
    for (int i = 0; i < size; i++)
        //keeping total to work out mean
        total = total + sorted[i];
        //searching through original array to find index position of median to connect it to original name
        if (arr[i] == median)
        index = i;
    int mean = total/size;
    //output median and mean
    std::cout << "Median is " << dealer[index] << " with " << median << " sales" << std::endl;
    std::cout << "Mean is " << mean << std::endl;
}

//main function
int main () {
    //intialising sorted and unsorted arrays and variables
    string dealer[15] = {"Barnet", "Birmingham", "Bradford", "Bristol", "Cheshire East"
                      , "Cornwall", "County Durham", "Coventry", "Croydon", "Kirklees", "Leeds"
                      , "Liverpool", "Manchester", "Sheffield", "Wiltshire"};
    int unsorted[15] = {3878, 11371, 5348, 4593, 3788, 5613, 5237, 3601, 3848, 4371, 7848, 4915, 5455, 5778, 4960};
    int sales[15] = {3878, 11371, 5348, 4593, 3788, 5613, 5237, 3601, 3848, 4371, 7848, 4915, 5455, 5778, 4960};
    int n = sizeof(sales)/sizeof(sales[0]);  
    //calling functions
    bubbleSort(sales, n);
    calculate(sales, n, unsorted, dealer);
    return 0;
}