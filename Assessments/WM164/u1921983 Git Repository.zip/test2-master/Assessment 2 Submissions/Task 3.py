singleNo = []  # numbers as single integers
new = []  # array used in sorting algorithm
sorted = []  # sorted sales values
sum = 0  # sum for mean
unformatted = []  # unformatted list including \n etc...
sales = []  # formatted list
numbers = []  # sales values in order given

# file handling - opening and reading file
filename = "/Users/jackyoung/Downloads/sales_data.txt"
file = open(filename, "r")

# setting up unformatted list of sales and names and single digits of sales
for line in file:
    array = []
    unformatted.append(line)
    for x in line:
        if x.isdigit():
            array.append(x)
    singleNo.append(array)
del singleNo[0]
del unformatted[0]

# replace the new line syntax with spaces
for i in unformatted:
    j = i.replace('\t', ' ')
    jj = j.replace('\n', ' ')
    sales.append(jj)

# make single digits into correct 4 digit sales
for y in range(0, len(singleNo)):
    string = ''
    for j in range(0, len(singleNo[y])):
        string = string + singleNo[y][j]
    numbers.append(int(string))

# copy sales numbers to new array for sorting
new = numbers.copy()

# sorting sales numbers
for i in range(0, len(numbers)):
    lowest = new[0]
    position = 0
    for x in range(0, len(new)):
        if new[x] < lowest:
            lowest = new[x]
            position = x
    del new[position]
    sorted.append(lowest)

# for loop for mean
for count in range(0, len(sorted)):
    sum = sum + sorted[count]
mean = sum/len(sorted)

# finding middle of sorted array for median
middle = int(len(sorted)/2 + 0.5)

# median is middle value of sorted array
median = sorted[middle]

# finding position of median in the original set of unsorted numbers
# to print location of median with number
index = numbers.index(median)

# print median and mean
print('Median is', sales[index])
print('Mean is', mean)
