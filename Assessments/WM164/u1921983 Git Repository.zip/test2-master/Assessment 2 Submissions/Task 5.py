# import libraries
import matplotlib.pyplot as plt
import numpy as np

# defining variables/lists
data_array = []
global data
data = []

# file opening as a read format
file = open("cars-stolen-2005.csv", "r")

# function to get lines of data into a
# 2 dimensional array skipping empty lines


def get_data():
    for line in file:
        line = line.replace("\n", "")
        array = []
        array = line.split(',')
        if array[0] != '\n':
            data_array.append(array)

# function to find highest period of stolen cars


def high_period():
    global data
    high = -1

    # empty array to put totals in
    high_array = [0, 0, 0, 0, 0, 0]

    # looping through the data array and searching
    # for lines of data using seletion statements

    for i in range(0, len(data_array)):
        if (len(data_array[i]) == 10 and data_array[i][4].find("-") == -1 and
            data_array[i][4] != ""):

            # when conditions are satisfied it loops through the
            # time periods and adds each one to the corresponding position

            for j in range(4, 10):
                high_array[j-4] = high_array[j-4] + int(data_array[i][j])

    # loop through high array to find highest number and taking
    # index to put back into the data array and find the time period

    for i in range(0, len(high_array)):
        if high_array[i] > high:
            high = high_array[i]
            index = i
    data = high_array
    print("The highest period for stolen cars is:",
          data_array[4][i+3], "with", high, "cars being stolen")

# function to find total number of cars stolen in each category


def top_category():
    mini = 0
    smallsal = 0
    medsal = 0
    larsal = 0
    luxsal = 0
    sports = 0
    fourxfour = 0
    total_list = []

    # looping through each total for each car and model
    # and appending to a new list for ease of manipulation

    for i in range(0, len(data_array)):
            if data_array[i][3].find("Total") == -1 and data_array[i][3] != "":
                total_list.append(int(data_array[i][3]))

    # loop with seletion statements splitting up each
    # category and then adding them to corresponding totals

    for i in range(0, len(total_list)):
        if i <= 171:
            mini = mini + total_list[i]
        elif i <= 372:
            smallsal = smallsal + total_list[i]
        elif i <= 494:
            medsal = medsal + total_list[i]
        elif i <= 565:
            larsal = larsal + total_list[i]
        elif i <= 582:
            luxsal = luxsal + total_list[i]
        elif i <= 647:
            sports = sports + total_list[i]
        elif i <= 744:
            fourxfour = fourxfour + total_list[i]
    print("Total superminis stolen is", mini)
    print("Total small saloons stolen is", smallsal)
    print("Total medium saloons stolen is", medsal)
    print("Total large saloons stolen is", larsal)
    print("Total luxury saloons on the road is", luxsal)
    print("Total sports cars stolen is", sports)
    print("Total 4x4s stolen is", fourxfour)
    print("Total number of cars stolen is", mini + smallsal + medsal +
          larsal + sports + fourxfour)

# calling functions
get_data()
high_period()
top_category()

# code using Matplotlib that prints a graph of all
# time period visualizing the totals for each period

plt.style.use('ggplot')

# x axis
x = ['2003-05', '2000-02', '1997-99', '1994-96', '1991-93', 'Pre-1991']

x_pos = [i for i, _ in enumerate(x)]

plt.bar(x_pos, data, color='green')

# lables for x and y axis
plt.xlabel("Time Period")
plt.ylabel("Number of cars stolen")
plt.title("Number of cars stolen in certain time periods")

plt.xticks(x_pos, x)

# shows the graph
plt.show()
