# defining calculator class
class Calculator:
    # init function required when defining a class
    def __init__(self):
        pass

    # function to get numbers

    def get_numbers(self):
        func = []
        x = ''
        print("Enter each number or operator line by line...")
        while x != '=':
            x = input(': ')
            if x.isdigit() is False:
                raise ValueError("X must be a number")
            else:
                func.append(x)
        return func
# defining calc as a calculator
calc = Calculator()
func = calc.get_numbers()
# main loop to loop through the mathematical
# function and find maths operators in order of BODMAS
for j in range(0, (len(func)-2)):
    if j == len(func):
        break
    if func[j] == '*':
        total = int(func[j-1]) * int(func[j+1])
        func[j+1] = total
        del func[j]
        del func[j-1]
    if func[j] == '/':
        total = int(func[j-1]) / int(func[j+1])
        func[j+1] = total
        del func[j]
        del func[j-1]
    if func[j] == '+':
        total = int(func[j-1]) + int(func[j+1])
        func[j+1] = total
        del func[j]
        del func[j-1]
    if func[j] == '-':
        total = int(func[j-1]) - int(func[j+1])
        func[j+1] = total
        del func[j]
        del func[j-1]
# by the time the function has been evaluated there should be 2 items left
# in the list: position 1, the answer, and position 2 the = sign
print(func[0])
