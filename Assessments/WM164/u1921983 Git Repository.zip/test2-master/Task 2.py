#initialising dictionary
cars = {'Land Rover': 'Velar', 'BWM': 'X5', 'Audi': 'Q5'}

carlist = list(cars.items())

#using string and dictionary manipulation to print the required output
stringprint = ("Brand" + (" ")*10+"|"+" "+"Model")
stringprint += ("\n----------------------")
stringprint += ("\n" + carlist[0][0] + (" ")*5+"|"+" "+ carlist[0][1])
stringprint += ("\n" + carlist[1][0] + (" ")*12+"|"+" "+ carlist[1][1])
stringprint += ("\n" + carlist[2][0] + (" ")*11+"|"+" "+ carlist[2][1])
print(stringprint)
