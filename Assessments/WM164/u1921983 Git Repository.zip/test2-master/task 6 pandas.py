import pandas as pd
import numpy as np    
import matplotlib

df = pd.read_csv('cars-stolen-2005.csv')
#df.columns = ['Manufacturer', 'Model','Variant','Total','2003-05','2000-02','1997-99','1994-96','1991-93','Pre-1991']
total = 0
#for i in df['Total']:
 #   if i.isnumeric():
  #      total = total + int(i)

print(df.iloc[31])