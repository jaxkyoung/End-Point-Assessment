import math
unformatted = []
angle = []
file = open("/Users/jackyoung/Desktop/Warwick Stuff/Year 1/Smart Solutions/Python files/text1", "r")
for line in file:
    if line != "$":
        unformatted.append(line)
    else:
        break
for i in unformatted:
    j = i.replace('\t','')
    jj = j.replace('\n','')
    angle.append(jj)
for i in range(0,len(angle)):
    angle[i] = float(angle[i])
print(angle)

sum = 0
for i in range(1,len(angle)):
    angle1 = angle[i] - angle[i-1]
    area = 0.5 * math.sin(math.pi * angle1)
    sum = sum + area

print('%.2f' % sum)