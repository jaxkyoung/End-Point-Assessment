# file 'test2.py'
def fun(a):
    '''
    >>> fun(3)
    6
    '''
    pass

if __name__ =='__main__':
    import doctest
    doctest.testmod()