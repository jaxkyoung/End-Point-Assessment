# Hi Jianhua

#### I have completed the following tasks:
    Task 3
    Task 4
    Task 5
    Task 7

### Please find the final code in the folder named "Assessment 2 Submissions"

