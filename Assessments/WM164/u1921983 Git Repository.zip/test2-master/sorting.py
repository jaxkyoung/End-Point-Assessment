scores = []
sorted = []
lowest = 10000
for count in range(0,5):
    score = input("Input a score")
    if score == "":
        score = 0
    scores.append(int(score))
print(scores)
for y in range(0,5):   
    lowest = scores[0]
    position = 0
    for x in range(0,len(scores)):
        if scores[x] < lowest:
            lowest = scores[x]
            position = x
        print(lowest)
    del scores[position]
    sorted.append(lowest)
print(scores)
print(sorted)
