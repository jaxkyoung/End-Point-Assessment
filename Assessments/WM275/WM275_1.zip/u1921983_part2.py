#!/usr/bin/env python
# coding: utf-8

from utils import *
from logic import *
# from notebook import psource

(AKnight, AKnave,BKnight, BKnave,CKnight, CKnave)= symbols("AKnight, AKnave,BKnight, BKnave,CKnight, CKnave")

# Puzzle 1
KBase1 = PropKB()
# This line tells us the KB the rules of the game: A player can either be a Knight or a Knave but NOT both. i.e. Knight XOR Knave.
# I have implemented it as (A is a Knight AND A is not a Knave) OR (A is a Knave and A is not a Knight). 
KBase1.tell((AKnight & ~AKnave) | (AKnave & ~AKnight))
# A says 'I am both a Knight and a Knave'. This is only true when A is a Knight
# So IF AKnight THEN AKnight AND AKnave
KBase1.tell(AKnight |'==>'| (AKnight & AKnave))
# If AKnave, it must lie. So IF AKnave THE NOT(AKnight AND AKnave)
KBase1.tell(AKnave |'==>'| ~(AKnight & AKnave))
# Since A cannot be both a Knight and Knave, it must be a Knave.

# Puzzle 2
KBase2 = PropKB()
# These lines tells us the KB the rules of the game: A player can either be a Knight or a Knave but NOT both. i.e. Knight XOR Knave.
# I have implemented it as (A is a Knight AND A is not a Knave) OR (A is a Knave and A is not a Knight). The same has been implemented for B
KBase2.tell((AKnight & ~AKnave) | (AKnave & ~AKnight))
KBase2.tell((BKnight & ~BKnave) | (BKnave & ~BKnight))
# A says 'we are both knaves' which translates to AKnight AND AKnave. However, this is only true when A is a Knight.
# So IF AKnight THEN AKnight AND AKnave translates to AKnight ==> AKnight & AKnave
KBase2.tell(AKnight |'==>'| (AKnave & BKnave))
# If A is a Knave then what it said must be a lie. So, IF AKnave THEN NOT(AKnight AND AKnave)
KBase2.tell(AKnave |'==>'|  ~(AKnave & BKnave))
# In this case, A cannot be a Knight as if it were, its statement would have to be true. So from here we can assume A is Knave
# If A is Knave, it must lie in its statement - 'we are both knaves' since A is a Knave the other can now no longer be a Knave.
# Therefore, A is a Knave and B is a Knight.

# Puzzle 3
KBase3 = PropKB()
# These lines tells us the KB the rules of the game: A player can either be a Knight or a Knave but NOT both. i.e. Knight XOR Knave.
# I have implemented it as (A is a Knight AND A is not a Knave) OR (A is a Knave and A is not a Knight). The same has been implemented for B
KBase3.tell((AKnight & ~AKnave) | (AKnave & ~AKnight))
KBase3.tell((BKnight & ~BKnave) | (BKnave & ~BKnight))
# A says 'we are the same kind' which translates to (AKnight AND BKnight) OR (AKnave and BKnave)
# If A is a Knight, then its statement must be true
# So IF AKnight THEN (AKnight AND BKnight) OR (AKnave AND BKnave)
KBase3.tell(AKnight |'==>'| ((AKnight & BKnight) | (AKnave & BKnave)))
# If A is a Knave, then its statement must be false
# So IF AKnave THEN NOT(AKnight AND BKnight) OR (AKnave AND BKnave)
KBase3.tell(AKnave |'==>'| ~((AKnight & BKnight) | (AKnave & BKnave)))
# B says 'we are of different kind' which translates to (AKnight AND BKnave) OR (AKnave and BKnight)
# If B is a Knight, then its statement must be true
# So IF BKnight THEN (AKnight AND BKnave) OR (AKnave AND BKnight)
KBase3.tell(BKnight |'==>'| ((AKnight & BKnave) | (AKnave & BKnight)))
# If B is a Knave, then its statement must be true
# So IF BKnave THEN NOT((AKnight AND BKnave) OR (AKnave AND BKnight))
KBase3.tell(BKnave |'==>'| ~((AKnight & BKnave) | (AKnave & BKnight)))
# If A were a knight, then they would both be of the same kind, but because B is a Knight due to A's statement, this entailment cant be true
# If A were a knave, then it would lie, so B would have to a Knight, which satisfies both statements
# Therefore A is a Knave and B is a Knight

# Puzzle 4
KBase4 = PropKB()
# These lines tells us the KB the rules of the game: A player can either be a Knight or a Knave but NOT both. i.e. Knight XOR Knave.
# I have implemented it as A is a Knight AND A is not a Knave OR A is a Knave and A is not a Knight. The same has been implemented for B and C
KBase4.tell((AKnight & ~AKnave) | (AKnave & ~AKnight))
KBase4.tell((BKnight & ~BKnave) | (BKnave & ~BKnight))
KBase4.tell((CKnight & ~CKnave) | (CKnave & ~CKnight))
# A says 'I am either a Knight or a Knave but you dont know which'
# If A is a Knight, then its statement must be true, so IF AKnight THEN AKnight OR AKnave
KBase4.tell(AKnight |'==>'| (AKnight | AKnave))
# If A is a Knave, then its statement must be false, so IF AKnave THEN NOT(AKnight OR Knave)
KBase4.tell(AKnave |'==>'| ~(AKnight | AKnave))
# A's statement will always be true, so i cannot tell a lie, therefore it must be a Knight
# B says 'A said "I am a Knave"'
# If B is a Knight then statement translates to IF BKnight THEN AKnave
KBase4.tell(BKnight |'==>'| (AKnave))
# If B is a Knave then the statement translates to IF BKnave THEN NOT(AKnave)
# Since we know A must be a Knight, then B must be a Knave
KBase4.tell(BKnave |'==>'| ~(AKnave))
# B says 'C is a Knave'
# If B is a Knight then the statement translates to IF BKnight THEN CKnave
KBase4.tell(BKnight |'==>'| (CKnave))
# If B is a Knave then the statement translates to IF BKnave THEN NOT(CKnave)
KBase4.tell(BKnave |'==>'| ~(CKnave))
# Since we know A is a Knight and B is a Knave, we can assume that B's statement about C is a lie, so C is a Knight
# If C is a Knight, then its statement must be true
# C says 'A is a Knight' which translates to IF CKnight THEN AKnight
KBase4.tell(CKnight |'==>'| (AKnight))
# If C is a Knave, then its statement must be false
# C says 'A is a Knight' which translates to IF CKnave THEN NOT(AKnight)
KBase4.tell(CKnave |'==>'| ~(AKnight))
# By using our previous sentences we can deduce that C is a Knight, so the valid entailments are AKnight, BKnave and CKnight

# This function checks if any of the symbols are entailed by a given knowledge base, run this to file to check if your
# knowledge base has all sentences necessary to answer your query. No answer will be print if the knowledge base does not entail the query.
def main():
    symbols = [AKnight, AKnave,BKnight, BKnave,CKnight, CKnave]
    puzzles = [
        ("Puzzle 1", KBase1),
        ("Puzzle 2", KBase2),
        ("Puzzle 3", KBase3),
        ("Puzzle 4", KBase4)
    ]
    for puzzle, knowledge in puzzles:
        print(puzzle)
        if len(knowledge.clauses) == 0:
            print("    Not yet implemented.")
        else:
            for symbol in symbols:
                if knowledge.ask_if_true(symbol): #model_check(knowledge, symbol):
                    print(f"    {symbol}")
    return


if __name__=="__main__":
    main()