"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

"""
Each algorithm shall follow a basic format that can be re-used for DFS, BFS and UCS.
Only the data structure holding the fringe shall change (as well as adding cost to UCS)
Stack = DFS (FILO)
Queue = BFS (FIFO)
Priority Queue = UCS (FIFO + Cost Weighting)
"""

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.
    """
    "*** u1921983 ***"

    # a list of the coordinates of visited nodes, on initalisation it is empty
    visited = set()
    # initialising a 'stack' defined in util.py to act as the 'fringe' of the graph search 
    # the stack utilizes a last in, first out method to allow for a depth first search instead of a breadth first
    fringe = util.Stack()
    # define the start node as the node returned from the PositionSearchProblem class's method - .getStartState()
    # .getStartState returns the coordinates of the starting state
    # start is defined as a tuple (Coordinates, Path)
    # where 'Path' is the path from the start node to the current node under investigation
    # in this case there is no path from the start node as we are looking at the start node hence []
    start = (problem.getStartState(), []) # start = ((XCoord, YCoord), Path)
    # add the start state to the stack as it is in the fringe
    fringe.push(start)
    # loop until a solution is found
    while True:
        # if fringe is empty (no more nodes to explore) then stop loop
        if fringe.isEmpty():
            # return false means loop condition is now False
            return False
        # pop will return the next item to be removed from the stack
        # set this as the node to be investigated
        node = fringe.pop()
        # extract the coordinates from this node and the path from the start to the node
        xy, path = node[0], node[1]
        # if the coordinates of the node under investigation are the goal state (.isGoalState returns true or false)
        # then a solution has been found
        if problem.isGoalState(xy):
            return path
        # if the current node has not been visited
        if xy not in visited:
            # add it to the visited set
            visited.add(xy)
            # investigate its child nodes
            # .getSuccessors(Coords) returns the child coordinates, the direction to get to them and the moves 'weight'
            # in the case of this problem all weights are 1 as defined the the lambda func costFn
            # print(child) will return a tuple of ((x,y), 'Direction', int(weight))
            # for each node next to the current node
            for child in problem.getSuccessors(xy):
                # add the direction you take to get to the child node and add it to the path of the previous node we visited
                newPath = node[1] + [child[1]]
                # the new state is the coordinates of the child node (position 0)
                newState = child[0]
                # push the newly discovered node to the fringe
                fringe.push((newState, newPath))


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # a list of the coordinates of visited nodes, on initalisation it is empty
    visited = set()
    # initialising a 'queue' defined in util.py to act as the 'fringe' of the graph search 
    # the stack utilizes a first in, first out method to allow for a breadth first search instead of a depth first
    fringe = util.Queue()
    # define the start node as the node returned from the PositionSearchProblem class's method - .getStartState()
    # .getStartState returns the coordinates of the starting state
    # start is defined as a tuple (Coordinates, Path)
    # where 'Path' is the path from the start node to the current node under investigation
    # in this case there is no path from the start node as we are looking at the start node hence []
    start = (problem.getStartState(), []) # start = ((XCoord, YCoord), Path)
    # add the start state to the stack as it is in the fringe
    fringe.push(start)
    # loop until a solution is found
    while True:
        # if fringe is empty (no more nodes to explore) then stop loop
        if fringe.isEmpty():
            # return false means loop condition is now False
            return False
        # pop will return the next item to be removed from the stack
        # set this as the node to be investigated
        node = fringe.pop()
        # extract the coordinates from this node and the path from the start to the node
        xy, path = node[0], node[1]
        # if the coordinates of the node under investigation are the goal state (.isGoalState returns true or false)
        # then a solution has been found
        if problem.isGoalState(xy):
            return path
        # if the current node has not been visited
        if xy not in visited:
            # add it to the visited set
            visited.add(xy)
            # investigate its child nodes
            # .getSuccessors(Coords) returns the child coordinates, the direction to get to them and the moves 'weight'
            # in the case of this problem all weights are 1 as defined the the lambda func costFn
            # print(child) will return a tuple of ((x,y), 'Direction', int(weight))
            # for each node next to the current node
            for child in problem.getSuccessors(xy):
                # add the direction you take to get to the child node and add it to the path of the previous node we visited
                newPath = node[1] + [child[1]]
                # the new state is the coordinates of the child node (position 0)
                newState = child[0]
                # push the newly discovered node to the fringe
                fringe.push((newState, newPath))
   

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # a list of the coordinates of visited nodes, on initalisation it is empty
    visited = set()
    # initialising a 'PriorityQueue' defined in util.py to act as the 'fringe' of the graph search 
    # the PriorityQueue utilizes a first in, first out method but the nodes in the queue are ordered by their cost
    fringe = util.PriorityQueue()
    # define the start node as the node returned from the PositionSearchProblem class's method - .getStartState()
    # .getStartState returns the coordinates of the starting state
    # start is defined as a tuple (Coordinates, Path)
    # where 'Path' is the path from the start node to the current node under investigation
    # in this case there is no path from the start node as we are looking at the start node hence []
    start = (problem.getStartState(), []) # start = ((XCoord, YCoord), Path)
    # add the start state to the stack as it is in the fringe
    fringe.push(start, 0)
    # loop until a solution is found
    while True:
        # if fringe is empty (no more nodes to explore) then stop loop
        if fringe.isEmpty():
            # return false means loop condition is now False
            return False
        # pop will return the next item to be removed from the stack
        # set this as the node to be investigated
        node = fringe.pop()
        # extract the coordinates from this node and the path from the start to the node
        xy, path = node[0], node[1]
        # if the coordinates of the node under investigation are the goal state (.isGoalState returns true or false)
        # then a solution has been found
        if problem.isGoalState(xy):
            return path
        # if the current node has not been visited
        if xy not in visited:
            # add it to the visited set
            visited.add(xy)
            # investigate its child nodes
            # .getSuccessors(Coords) returns the child coordinates, the direction to get to them and the moves 'weight'
            # in the case of this problem all weights are 1 as defined the the lambda func costFn
            # print(child) will return a tuple of ((x,y), 'Direction', int(weight))
            # for each node next to the current node
            for child in problem.getSuccessors(xy):
                # cost is the 3rd item in each of the successors tuples
                cost = child[2]
                # add the direction you take to get to the child node and add it to the path of the previous node we visited
                newPath = node[1] + [child[1]]
                # the new state is the coordinates of the child node (position 0)
                newState = child[0]
                # push the newly discovered node to the fringe
                fringe.push((newState, newPath), cost)

    
def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
